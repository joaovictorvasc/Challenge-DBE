package br.com.daredev.project.models;

import javax.persistence.*;
import java.util.List;

@Table(name = "TB_LIVRO")
@SequenceGenerator(name = "SQ_LIVRO", sequenceName = "SQ_LIVRO", initialValue = 1)
@Entity
public class Livro {

    @Id
    @Column(name = "id_livro")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ_LIVRO")
    private Long id;

    @Column(name = "nm_livro")
    private String nome;

    @Column(name = "nm_autor")
    private String autor;

    @Column(name = "ds_genero")
    private String genero;

    @Column(name = "qt_paginas")
    private int paginas;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;

    public Livro() {
    }

    public Livro(Long id, String nome, String autor, String genero, int paginas, Usuario usuario) {
        this.id = id;
        this.nome = nome;
        this.autor = autor;
        this.genero = genero;
        this.paginas = paginas;
        this.usuario = usuario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getPaginas() {
        return paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
