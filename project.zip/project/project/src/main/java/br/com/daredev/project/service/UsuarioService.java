package br.com.daredev.project.service;

import br.com.daredev.project.repository.UsuarioRepository;
import br.com.daredev.project.models.Usuario;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UsuarioService {

    private final UsuarioRepository repository;
//    private final PasswordEncoder passwordEncoder;

    public UsuarioService(UsuarioRepository repository) { this.repository = repository;
//        this.passwordEncoder = passwordEncoder;
    }

    public Usuario cadastrar(Usuario usuario){
//        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        return repository.save(usuario);
    }

}
