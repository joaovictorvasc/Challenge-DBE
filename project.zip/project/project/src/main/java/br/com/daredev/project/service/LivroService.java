package br.com.daredev.project.service;

import br.com.daredev.project.models.Livro;
import br.com.daredev.project.repository.LivroRepository;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;

@Service
public class LivroService {

    private final LivroRepository repository;

    public LivroService(LivroRepository repository) {this.repository = repository;}

    public Livro cadastrar(Livro livro) { return repository.save(livro);}


    public void deletar(Long id) {
        Livro livro = repository.findById(id).orElseThrow(()->new EntityNotFoundException("id não encontrado"));
        repository.delete(livro);
    }


    public Livro encontrar(Long id) {
        return repository.findById(id).orElseThrow(()->new EntityNotFoundException("id não encontrado"));

    }

    public List<Livro> encontrarTodos() {
        return repository.findAll();

    }

    public Livro atualizar(Long id, livro livroAtualizado){
       Livro livro = this.encontrar(id);
       livroAtualizado.setId(livro.getId());
       return repository.save(livroAtualizado);
    }


}


