package br.com.daredev.project.controller;

import br.com.daredev.project.models.Livro;
import br.com.daredev.project.dto.LivroDto;
import br.com.daredev.project.mapper.LivroMapper;
import br.com.daredev.project.service.LivroService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/livro/")
public class LivroController {

    private final LivroService livroService;

    public LivroController(LivroService livroService) { this.livroService  = livroService; }

    @PostMapping
    public ResponseEntity<LivroDto> cadastrarLivro(@RequestBody LivroDto response) {
        try {
            livroService.cadastrar(LivroMapper.dtoParaLivro(response));
            return new ResponseEntity<LivroDto>(response, HttpStatus.CREATED);
        }catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @DeleteMapping("{id}")
    public ResponseEntity<LivroDto> deletarLivro(@PathVariable(value = "id") Long id){

        try{
            livroService.deletar(id);
          return ResponseEntity.noContent().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }

    }

    @GetMapping("{id}")
    public ResponseEntity<LivroDto> encontrarLivro(@PathVariable(value = "id") Long id){
        try {
           Livro livro = livroService.encontrar(id);
           return ResponseEntity.ok(LivroMapper.livroParaDto(livro));
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public ResponseEntity<java.lang.Object> encontrarTodosLivro(){
        try {
            List<Livro> livro = livroService.encontrarTodos();
            return ResponseEntity.ok(LivroMapper.listaLivroParaLivroDto(livro));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("{id}")
    public ResponseEntity<LivroDto> atualizarLivro(@PathVariable(value = "id") Long id, @RequestBody LivroDto livroDto){
        try {
            Livro livro = livroService.atualizar(id, LivroMapper.dtoParaLivro(livroDto));
           return ResponseEntity.ok(LivroMapper.livroParaDto(livro));
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }


}
