package br.com.daredev.project.mapper;

import br.com.daredev.project.models.Livro;
import br.com.daredev.project.dto.LivroDto;

import java.util.ArrayList;
import java.util.List;

public class LivroMapper {

    public static Livro dtoParaLivro(LivroDto dto){
        return new Livro(dto.getName(), dto.getNumber(), null);
    }

    public static LivroDto livroParaDto(Livro livro){
        return new LivroDto(livro.getName(), livro.getNumber());
    }

    public static List<LivroDto> listaLivroParaLivroDto (List<Livro> listLivro){
        List<LivroDto> livros = new ArrayList<>();
        listLivro.forEach(livro -> livros.add(new LivroDto(livro.getName(), livro.getNumber())));
        return livros;
    }


}
