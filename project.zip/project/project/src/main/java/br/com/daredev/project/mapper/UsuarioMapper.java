package br.com.daredev.project.mapper;

import br.com.daredev.project.dto.UsuarioDto;
import br.com.daredev.project.models.Usuario;

public class UsuarioMapper {

    public static Usuario dtoParaUsuario(UsuarioDto dto){
        return new Usuario(null, dto.getName(), dto.getEmail(), dto.getSenha(), null);
    }

}
